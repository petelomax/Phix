/*
  Show Ident and Integers
 */
phoenix_number = 142857;
print(phoenix_number, "\n");
