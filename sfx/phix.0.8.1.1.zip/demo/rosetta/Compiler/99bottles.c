/* 99 bottles */
bottles = 99;
while (bottles >= 0) {
    print(bottles, " bottles of beer on the wall\n");
    print(bottles, " bottles of beer\n");
    print("Take one down, pass it around\n");
    print(bottles, " bottles of beer on the wall\n\n");
    bottles = bottles - 1;
}
