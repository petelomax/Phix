 -- Computer Language Shootout
 -- http://shootout.alioth.debian.org/
 --
 --  by Jason Gade
 --  run: exu startup.ex

puts(1, "hello world\n")

